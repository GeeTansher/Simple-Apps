package com.example.carownerinfoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btncarInfo,btnownerInfo;
    ImageView ivmake;
    TextView tvmodel,tvname,tvtel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btncarInfo=findViewById(R.id.btncarInfo);
        btnownerInfo=findViewById(R.id.btnownerInfo);
        tvmodel=findViewById(R.id.tvmodel);
        tvname=findViewById(R.id.tvname);
        tvtel=findViewById(R.id.tvtel);
        ivmake=findViewById(R.id.ivmake);

        btncarInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnownerInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}